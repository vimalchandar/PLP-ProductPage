package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory();
	     /*Inventory inventory1=new Inventory("laptop", 3, 50.0, "Electro", 2.5,2.5);
	     Inventory inventory2=new Inventory("jeans", 3, 25000.0, "clothing", 3.5,4.1);
	     "Mobile", 3, 25000.0, "Electro", 25.5,4.5*/
	     inventory.setMerchant(merchant);
	     /*inventory1.setMerchant(merchant);
	     inventory2.setMerchant(merchant);*/
	 
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	    /* entityManager.persist(inventory1);
	     entityManager.persist(inventory2);*/
	    
	     entityManager.persist(customer);
	     entityManager.flush();
	   
	   
	}
	@Override
	public List<Inventory> show(String type) {
		// TODO Auto-generated method stub
		
		TypedQuery<Inventory> query=entityManager.createQuery("select s from Inventory s where s.inventoryType=:typ",Inventory.class);
		query.setParameter("typ",type);
		return query.getResultList();
	}
	
			//
	/*@Override
	public String find(int i) {
		Inventory inventory=entityManager.find(Inventory.class,i);
		return inventory.getFileName();
	}*/
}
