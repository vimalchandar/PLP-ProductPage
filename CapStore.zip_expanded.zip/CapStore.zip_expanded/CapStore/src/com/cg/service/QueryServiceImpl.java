package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Inventory;

@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO iQueryDAO;
	
	

	@Override
	public void plp() {
		iQueryDAO.plp();
	}

	

	@Override
	public List<Inventory> show(String type) {
		// TODO Auto-generated method stub
		return iQueryDAO.show(type);
	}

	

	/*@Override
	public String find(int i) {
		return iQueryDAO.find(i);
	}*/
	
}
