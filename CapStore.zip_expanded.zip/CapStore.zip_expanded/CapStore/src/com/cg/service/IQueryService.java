package com.cg.service;

import java.util.List;

import com.cg.entities.Inventory;

public interface IQueryService {

	// List<QueryAnswers> getall();
void plp();
public List<Inventory> show(String type);
//String find(int i);

}
