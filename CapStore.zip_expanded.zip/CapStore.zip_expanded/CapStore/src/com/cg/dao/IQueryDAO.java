package com.cg.dao;

import java.util.List;

import com.cg.entities.Inventory;

public interface IQueryDAO {
	
	void plp();

	//String find(int i);
	public List<Inventory> show(String type);
	
}
